$(function () {

    //Handling the login form
    $("#login-form form").submit(function (event) {

        //preveneting the default form submit event/behaviour/action
        event.preventDefault();
        var userEmail = $(this).find("#login-email").val();
        var userPassword = $(this).find("#login-password").val();
        $.ajax({
            type: "POST",
            url: 'http://localhost:8080/login',
            data: {
                email: userEmail,
                password: userPassword
            },
            success: function (response) {
                console.log(response);
            },
            dataType: "json"
        });
    });

//  Ends login form 
    $("#signup-form button").on('click', function () {
        console.log("button clicked");
    })

    $("#signup-form form").submit(function () {
        console.log("submitting");
        //preveneting the default form submit event/behaviour/action
        event.preventDefault();
        
    });

});