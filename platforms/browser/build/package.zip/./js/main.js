$(function () {

    //Function to center the elements
    
});